<template>
  <div class="p-4">
    <div class="max-w-6xl mx-auto bg-white rounded-lg shadow-md">
      <div class="p-6 border-b border-gray-200">
        <h2 class="text-3xl font-bold text-indigo-800">Foire Aux Questions</h2>
        <p class="text-slate-600 mt-4 text-sm">Retrouvez ici les réponses aux questions les plus fréquentes sur l'utilisation de l'assistant IA Campus France.</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
        <div class="faq-item bg-indigo-50 p-6 rounded-lg border border-indigo-200 transition-transform duration-300 hover:translate-x-3">
          <h3 class="text-lg font-semibold text-indigo-700 mb-2">Comment créer un compte ?</h3>
          <p class="text-slate-600 text-sm leading-relaxed">Cliquez sur le bouton « Créer un compte » en haut à droite de la page d'accueil, puis remplissez le formulaire d'inscription avec vos informations personnelles.</p>
        </div>
        <div class="faq-item bg-indigo-50 p-6 rounded-lg border border-indigo-200 transition-transform duration-300 hover:translate-x-3">
          <h3 class="text-lg font-semibold text-indigo-700 mb-2">L'assistant IA est-il gratuit ?</h3>
          <p class="text-slate-600 text-sm leading-relaxed">Oui, l'accès de base à l'assistant IA Campus France est gratuit pour tous les étudiants et candidats. Certaines fonctionnalités avancées peuvent être payantes.</p>
        </div>
        <div class="faq-item bg-indigo-50 p-6 rounded-lg border border-indigo-200 transition-transform duration-300 hover:translate-x-3">
          <h3 class="text-lg font-semibold text-indigo-700 mb-2">Comment l'IA peut-elle m'aider dans mes démarches ?</h3>
          <p class="text-slate-600 text-sm leading-relaxed">L'assistant IA vous guide pour remplir vos dossiers, rédiger vos lettres de motivation, répondre à vos questions sur les procédures Campus France et bien plus encore.</p>
        </div>
        <div class="faq-item bg-indigo-50 p-6 rounded-lg border border-indigo-200 transition-transform duration-300 hover:translate-x-3">
          <h3 class="text-lg font-semibold text-indigo-700 mb-2">Mes données sont-elles sécurisées ?</h3>
          <p class="text-slate-600 text-sm leading-relaxed">Oui, la sécurité et la confidentialité de vos données sont une priorité. Toutes les informations sont protégées et ne sont jamais partagées sans votre consentement.</p>
        </div>
        <div class="faq-item bg-indigo-50 p-6 rounded-lg border border-indigo-200 transition-transform duration-300 hover:translate-x-3">
          <h3 class="text-lg font-semibold text-indigo-700 mb-2">Comment contacter le support ?</h3>
          <p class="text-slate-600 text-sm leading-relaxed">Vous pouvez contacter notre équipe support via le formulaire de contact disponible en bas de page ou par email à support@iacampusfrance.com.</p>
        </div>
        <div class="faq-item bg-indigo-50 p-6 rounded-lg border border-indigo-200 transition-transform duration-300 hover:translate-x-3">
          <h3 class="text-lg font-semibold text-indigo-700 mb-2">Puis-je utiliser l'assistant IA sur mobile ?</h3>
          <p class="text-slate-600 text-sm leading-relaxed">Oui, la plateforme est accessible sur mobile et tablette via votre navigateur. Une application mobile dédiée sera bientôt disponible.</p>
        </div>
      </div>
    </div>
  </div>
</template> 