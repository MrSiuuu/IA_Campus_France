<template>
  <div id="how-it-works" class="px-4 sm:px-10 md:mt-28 mt-20">
    <div class="max-w-screen-xl mx-auto">
      <div class="max-w-2xl mx-auto text-center">
        <h2 class="lg:text-4xl text-3xl font-bold mb-6 md:!leading-[45px] leading-[40px]">
          Comment <span class="text-blue-700">ça marche</span>
        </h2>
        <p class="text-slate-700 text-base leading-relaxed">Simplifiez vos démarches Campus France en quelques clics grâce à notre assistant IA intelligent.</p>
      </div>

      <div class="grid lg:grid-cols-2 items-center gap-x-12 gap-y-16 mt-16">
        <div>
          <div class="mb-6 flex">
            <div class="mr-4">
              <div class="flex items-center justify-center bg-blue-700 text-white font-semibold rounded-full w-7 h-7">1</div>
            </div>
            <div>
              <h3 class="text-lg font-bold mb-3">Créez votre compte étudiant</h3>
              <p class="text-slate-700">Inscrivez-vous gratuitement avec votre email étudiant et accédez immédiatement à notre assistant IA pour vous guider dans vos démarches.</p>
            </div>
          </div>

          <div class="mb-6 flex">
            <div class="mr-4">
              <div class="flex items-center justify-center bg-blue-700 text-white font-semibold rounded-full w-7 h-7">2</div>
            </div>
            <div>
              <h3 class="text-lg font-bold mb-3">Décrivez votre projet d'études</h3>
              <p class="text-slate-700">Partagez vos objectifs académiques, votre niveau d'études et vos préférences. Notre IA analyse votre profil pour vous proposer un parcours personnalisé.</p>
            </div>
          </div>

          <div class="mb-6 flex">
            <div class="mr-4">
              <div class="flex items-center justify-center bg-blue-700 text-white font-semibold rounded-full w-7 h-7">3</div>
            </div>
            <div>
              <h3 class="text-lg font-bold mb-3">Recevez un accompagnement personnalisé</h3>
              <p class="text-slate-700">Notre assistant vous guide étape par étape : choix des formations, constitution du dossier, préparation aux entretiens, et suivi de votre candidature.</p>
            </div>
          </div>

          <div class="flex">
            <div class="mr-4">
              <div class="flex items-center justify-center bg-blue-700 text-white font-semibold rounded-full w-7 h-7">4</div>
            </div>
            <div>
              <h3 class="text-lg font-bold mb-3">Réussissez votre projet d'études</h3>
              <p class="text-slate-700">Bénéficiez d'un suivi continu et de conseils avisés pour maximiser vos chances d'admission dans l'établissement de vos rêves en France.</p>
            </div>
          </div>
        </div>
        <div class="w-full max-lg:-order-1 px-2">
          <img src="/images/pc-gamer-wall.jpg" alt="Comment ça marche" class="w-full rounded-lg shadow-lg" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
// Pas besoin de logique spécifique pour ce composant
</script> 