<template>
  <div class="min-h-screen flex items-center justify-center bg-base-200 py-8">
    <ReportForm />
  </div>
</template>

<script setup>
import ReportForm from '../components/ReportForm.vue'
</script> 