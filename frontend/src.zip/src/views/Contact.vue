<template>
  <div class="min-h-screen flex items-center justify-center bg-base-200 py-8">
    <ContactForm />
  </div>
</template>

<script setup>
import ContactForm from '../components/ContactForm.vue'
</script> 