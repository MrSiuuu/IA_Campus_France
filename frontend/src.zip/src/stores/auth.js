import { defineStore } from 'pinia'
import axios from '../config/axios'
import router from '../router'

function isTokenExpired(token) {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]))
    return payload.exp * 1000 < Date.now()
  } catch (e) {
    return true
  }
}

export const useAuthStore = defineStore('auth', {
  state: () => ({
    isAuthenticated: false,
    user: null,
    session: null,
    checkInterval: null
  }),
  actions: {
    login(session, user) {
      if (!session || !session.access_token) {
        console.error('Session invalide')
        return
      }
      
      // Stocker la session et l'utilisateur
      this.session = session
      this.user = user
      this.isAuthenticated = true
      
      // Stocker dans le localStorage
      localStorage.setItem('token', JSON.stringify(session))
      localStorage.setItem('user', JSON.stringify(user))

      // Démarrer la vérification périodique
      this.startTokenCheck()
    },
    async logout() {
      // Nettoyer le state
      this.session = null
      this.user = null
      this.isAuthenticated = false
      
      // Nettoyer le localStorage
      localStorage.removeItem('token')
      localStorage.removeItem('user')

      // Arrêter la vérification périodique
      this.stopTokenCheck()

      // Rediriger vers la page de connexion
      if (router.currentRoute.value.path !== '/login') {
        await router.push('/login')
      }
    },
    async checkAuth() {
      try {
        const token = localStorage.getItem('token')
        const user = localStorage.getItem('user')
        
        if (!token || !user) {
          await this.logout()
          return
        }
        
        const session = JSON.parse(token)
        const parsedUser = JSON.parse(user)
        
        if (!session.access_token || isTokenExpired(session.access_token)) {
          await this.logout()
          return
        }

        // Vérifier côté serveur si le token est encore valide
        const response = await axios.get('/api/auth/verify-token')
        if (!response.data.valid) {
          await this.logout()
          return
        }
        
        this.session = session
        this.user = parsedUser
        this.isAuthenticated = true

        // Démarrer la vérification périodique
        this.startTokenCheck()
      } catch (error) {
        console.error('Erreur lors de la vérification de l\'authentification:', error)
        await this.logout()
      }
    },
    async checkToken() {
      try {
        const token = localStorage.getItem('token')
        if (!token) {
          await this.logout()
          return false
        }

        const session = JSON.parse(token)
        if (!session.access_token || isTokenExpired(session.access_token)) {
          await this.logout()
          return false
        }

        // Rafraîchir le token côté serveur
        const response = await axios.post('/api/auth/refresh-token')
        if (response.data.session) {
          // Mettre à jour la session
          this.session = response.data.session
          localStorage.setItem('token', JSON.stringify(response.data.session))
          return true
        }
        
        await this.logout()
        return false
      } catch (error) {
        console.error('Erreur lors de la vérification du token:', error)
        await this.logout()
        return false
      }
    },
    startTokenCheck() {
      this.stopTokenCheck()
      this.checkInterval = setInterval(async () => {
        if (!this.isAuthenticated) return
        await this.checkToken()
      }, 1000 * 60 * 55)
    },
    stopTokenCheck() {
      if (this.checkInterval) {
        clearInterval(this.checkInterval)
        this.checkInterval = null
      }
    }
  }
}) 